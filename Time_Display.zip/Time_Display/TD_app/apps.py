from django.apps import AppConfig


class TdAppConfig(AppConfig):
    name = 'TD_app'
